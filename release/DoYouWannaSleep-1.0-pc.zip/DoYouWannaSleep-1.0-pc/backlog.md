# Do You Wanna Sleep with Me ?
- Limited Bedrooms / Bed

## Specs
- Background 128x72 resize 1280x720
- Palette  endSGA 32

## choix ange gardien
- kinky
- kind

## score

## Graphisme taille du lit / nombre de lit

## skills
- charism ❤️
- intellect Z
❤️

## lieux
- Ciel Heaven
- Enfer
- Chambre

#### 
- Bibliothèque ❤️ ou Z
- Magasin Brico + ❤️ ou Z
- Magasin Litterie -> augmenterbedroom capacity
- Magasin Love + ❤️
- Cinema ❤️ ou Z
- Centre Equestre ❤️ ou Z
- Cours de dance ❤️
- Bar / Pub ❤️
- Discothèque ❤️
- Centre meditation Z
- Beauty Center ❤️
